#ifndef DEVICE_STORAGE_H
#define DEVICE_STORAGE_H

#include "stm32f0xx_hal.h"
#include <stdint.h>

// 故障码定义
typedef enum {
    FAULT_NONE = 0x00,
    FAULT_WATER_OUTLET = 0x01,    // 出水口故障
    FAULT_TEMP_OVER = 0x02,       // 温度过高
    FAULT_PUMP = 0x03,            // 水泵故障
    FAULT_HEATER = 0x04,          // 加热器故障
    FAULT_SENSOR = 0x05,          // 传感器故障
    FAULT_MAX                     // 故障码边界值
} FaultCode;

// 设备运行状态定义
typedef enum {
    STATE_STANDBY = 0x00,         // 待机状态
    STATE_CHILD_LOCK = 0x01,      // 童锁状态
    STATE_HEATING = 0x02,         // 加热状态
    STATE_DISINFECTING = 0x03,    // 消毒状态
    STATE_ERROR = 0x04            // 错误状态
} DeviceState;

// 存储的数据结构
typedef struct {
    FaultCode last_fault;         // 最后一次故障码
    DeviceState last_state;       // 上一次运行状态
    uint8_t last_temp_setting;    // 上一次设置温度
    uint8_t disinfect_finish;     // 消毒完成标志(0:未完成, 1:已完成)
    uint32_t crc_checksum;        // CRC校验值，用于验证数据有效性
} DeviceStorageData;

// 初始化存储系统
void Storage_Init(void);

// 从Flash读取设备数据
HAL_StatusTypeDef Storage_ReadData(DeviceStorageData *data);

// 将设备数据写入Flash
HAL_StatusTypeDef Storage_WriteData(DeviceStorageData *data);

// 计算CRC校验值
uint32_t Storage_CalculateCRC(const uint8_t *data, uint32_t length);

#endif // DEVICE_STORAGE_H
    