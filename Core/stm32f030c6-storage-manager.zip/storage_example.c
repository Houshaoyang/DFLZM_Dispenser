#include "device_storage.h"
#include "stm32f0xx_hal.h"

// 示例：初始化存储系统
void Example_InitStorage() {
    // 在系统初始化时调用
    Storage_Init();
}

// 示例：设备状态发生变化时保存
void Example_SaveDeviceState(DeviceState new_state) {
    // 更新并保存运行状态
    HAL_StatusTypeDef status = Storage_UpdateState(new_state);
    if (status != HAL_OK) {
        // 处理保存失败的情况，例如点亮错误指示灯
    }
}

// 示例：温度设置改变时保存
void Example_SaveTemperatureSetting(uint8_t new_temp) {
    HAL_StatusTypeDef status = Storage_UpdateTemperature(new_temp);
    if (status != HAL_OK) {
        // 处理保存失败
    }
}

// 示例：检测到故障时保存
void Example_SaveFault(FaultCode fault) {
    HAL_StatusTypeDef status = Storage_UpdateFaultCode(fault);
    if (status != HAL_OK) {
        // 处理保存失败
    }
}

// 示例：读取上次保存的设备信息
void Example_LoadLastState() {
    DeviceStorageData *data = Storage_GetCurrentData();
    
    // 恢复上次设置的温度
    uint8_t last_temp = data->last_temp_setting;
    // 恢复上次的运行状态
    DeviceState last_state = data->last_state;
    // 恢复故障码
    FaultCode last_fault = data->last_fault;
    // 恢复消毒标志
    uint8_t disinfect_flag = data->disinfect_finish;
    
    // 应用这些恢复的值（例如设置当前温度为上次保存的值）
    // ...
}

// 主循环中的示例用法
void Example_MainLoop() {
    // 模拟：当检测到出水口故障时
    if (/* 检测到出水口故障 */ 0) {
        Example_SaveFault(FAULT_WATER_OUTLET);
    }
    
    // 模拟：当温度设置改变时
    if (/* 温度设置改变 */ 0) {
        Example_SaveTemperatureSetting(45);  // 保存新的温度设置
    }
    
    // 模拟：当消毒完成时
    if (/* 消毒完成 */ 0) {
        Storage_UpdateDisinfectFlag(1);  // 更新消毒完成标志
    }
}
    