#include "device_storage.h"

// STM32F030C6T6 Flash配置 (32KB Flash, 16页, 每页2KB)
// 使用最后一页存储数据，避免与程序代码冲突
#define FLASH_STORAGE_PAGE       15                  // 最后一页
#define FLASH_PAGE_SIZE          2048                // 每页大小
#define FLASH_STORAGE_ADDR       (0x08000000 + (FLASH_STORAGE_PAGE * FLASH_PAGE_SIZE))  // 存储地址

// 数据缓冲区(在RAM中)
static DeviceStorageData storage_buffer;

// 检查地址是否在Flash范围内
static uint8_t IsValidFlashAddress(uint32_t address) {
    return (address >= 0x08000000) && (address < (0x08000000 + 32 * 1024));
}

// Flash解锁
static HAL_StatusTypeDef Flash_Unlock(void) {
    if (HAL_FLASH_GetState() == FLASH_STATE_LOCKED) {
        return HAL_FLASH_Unlock();
    }
    return HAL_OK;
}

// Flash锁定
static void Flash_Lock(void) {
    HAL_FLASH_Lock();
}

// 擦除存储页
static HAL_StatusTypeDef Flash_EraseStoragePage(void) {
    FLASH_EraseInitTypeDef erase_init;
    uint32_t page_error;
    
    if (!IsValidFlashAddress(FLASH_STORAGE_ADDR)) {
        return HAL_ERROR;
    }
    
    erase_init.TypeErase = FLASH_TYPEERASE_PAGES;
    erase_init.PageAddress = FLASH_STORAGE_ADDR;
    erase_init.NbPages = 1;
    
    return HAL_FLASHEx_Erase(&erase_init, &page_error);
}

// 初始化存储系统
void Storage_Init(void) {
    // 读取数据，如果数据无效则初始化默认值
    DeviceStorageData temp_data;
    if (Storage_ReadData(&temp_data) != HAL_OK) {
        // 设置默认值
        storage_buffer.last_fault = FAULT_NONE;
        storage_buffer.last_state = STATE_STANDBY;
        storage_buffer.last_temp_setting = 25;  // 默认25°C
        storage_buffer.disinfect_finish = 1;    // 默认已完成
        storage_buffer.crc_checksum = Storage_CalculateCRC(
            (uint8_t*)&storage_buffer, 
            sizeof(DeviceStorageData) - sizeof(uint32_t)
        );
        
        // 写入默认数据
        Storage_WriteData(&storage_buffer);
    } else {
        storage_buffer = temp_data;
    }
}

// 计算CRC校验值
uint32_t Storage_CalculateCRC(const uint8_t *data, uint32_t length) {
    if (data == NULL || length == 0) {
        return 0;
    }
    
    uint32_t crc = 0xFFFFFFFF;
    for (uint32_t i = 0; i < length; i++) {
        crc ^= (uint32_t)data[i];
        for (uint8_t j = 8; j > 0; j--) {
            if (crc & 0x00000001) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
    }
    return ~crc;
}

// 从Flash读取设备数据
HAL_StatusTypeDef Storage_ReadData(DeviceStorageData *data) {
    if (data == NULL || !IsValidFlashAddress(FLASH_STORAGE_ADDR)) {
        return HAL_ERROR;
    }
    
    // 从Flash读取数据
    DeviceStorageData *flash_data = (DeviceStorageData*)FLASH_STORAGE_ADDR;
    *data = *flash_data;
    
    // 计算并验证CRC
    uint32_t calculated_crc = Storage_CalculateCRC(
        (uint8_t*)data, 
        sizeof(DeviceStorageData) - sizeof(uint32_t)
    );
    
    if (calculated_crc != data->crc_checksum) {
        return HAL_ERROR;  // CRC校验失败，数据无效
    }
    
    return HAL_OK;
}

// 将设备数据写入Flash
HAL_StatusTypeDef Storage_WriteData(DeviceStorageData *data) {
    if (data == NULL || !IsValidFlashAddress(FLASH_STORAGE_ADDR)) {
        return HAL_ERROR;
    }
    
    // 计算CRC校验值
    data->crc_checksum = Storage_CalculateCRC(
        (uint8_t*)data, 
        sizeof(DeviceStorageData) - sizeof(uint32_t)
    );
    
    // 解锁Flash
    HAL_StatusTypeDef status = Flash_Unlock();
    if (status != HAL_OK) {
        return status;
    }
    
    // 关闭中断，防止Flash操作被打断
    __disable_irq();
    
    // 擦除存储页
    status = Flash_EraseStoragePage();
    if (status == HAL_OK) {
        // 写入数据（按32位字写入）
        uint32_t *data_ptr = (uint32_t*)data;
        uint32_t flash_addr = FLASH_STORAGE_ADDR;
        
        for (uint32_t i = 0; i < sizeof(DeviceStorageData) / sizeof(uint32_t); i++) {
            status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, flash_addr, data_ptr[i]);
            if (status != HAL_OK) {
                break;
            }
            flash_addr += sizeof(uint32_t);
        }
    }
    
    // 恢复中断
    __enable_irq();
    
    // 锁定Flash
    Flash_Lock();
    
    // 更新本地缓冲区
    storage_buffer = *data;
    
    return status;
}

// 辅助函数：获取当前存储的数据
DeviceStorageData* Storage_GetCurrentData(void) {
    return &storage_buffer;
}

// 辅助函数：更新并保存故障码
HAL_StatusTypeDef Storage_UpdateFaultCode(FaultCode fault) {
    storage_buffer.last_fault = fault;
    return Storage_WriteData(&storage_buffer);
}

// 辅助函数：更新并保存运行状态
HAL_StatusTypeDef Storage_UpdateState(DeviceState state) {
    storage_buffer.last_state = state;
    return Storage_WriteData(&storage_buffer);
}

// 辅助函数：更新并保存设置温度
HAL_StatusTypeDef Storage_UpdateTemperature(uint8_t temp) {
    storage_buffer.last_temp_setting = temp;
    return Storage_WriteData(&storage_buffer);
}

// 辅助函数：更新并保存消毒完成标志
HAL_StatusTypeDef Storage_UpdateDisinfectFlag(uint8_t flag) {
    storage_buffer.disinfect_finish = flag;
    return Storage_WriteData(&storage_buffer);
}
    